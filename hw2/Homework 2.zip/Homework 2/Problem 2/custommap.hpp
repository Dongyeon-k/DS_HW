#include <functional>
#include <iostream>
#include <string>

// Implement empty templates, classes, and required member functions.

// TODO
template <>
class TreeNode {};

// TODO
template <>
class CustomMap {};
