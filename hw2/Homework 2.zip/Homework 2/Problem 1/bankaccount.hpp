#include <cstddef>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>

struct Transaction {
    double deposit;
    double withdraw;
    double balance;
};

class BankAccount {
   protected:
    double balance;
    std::vector<Transaction> transactionHistory;

   public:
    /*============================= 1.1.1. =============================*/
    // TODO

    /*============================= 1.1.2. =============================*/
    // TODO

    /*============================= 1.1.3. =============================*/
    // TODO

    /*============================= 1.1.4. =============================*/
    // TODO

    /*============================= 1.1.5. =============================*/
    // TODO

    // Do not modify this section.
    virtual ~BankAccount() {}
};

class SavingsAccount : public BankAccount {
   private:
    double interestRate;

   public:
    /*============================= 1.2.1. =============================*/
    // TODO

    /*============================= 1.2.2. =============================*/
    // TODO

    /*============================= 1.2.3. =============================*/
    // TODO
};

class CheckingAccount : public BankAccount {
   private:
    double transactionFee;

   public:
    /*============================= 1.3.1. =============================*/
    // TODO

    /*============================= 1.3.2. =============================*/
    // TODO

    /*============================= 1.3.3. =============================*/
    // TODO
};

class BusinessAccount : public BankAccount {
   private:
    double creditLine;

   public:
    /*============================= 1.4.1. =============================*/
    // TODO

    /*============================= 1.4.2. =============================*/
    // TODO

    /*============================= 1.4.3. =============================*/
    // TODO
};

class AccountManager {
   private:
    std::vector<std::shared_ptr<BankAccount>> accounts;

   public:
    /*============================= 1.5.1. =============================*/
    // TODO

    /*============================= 1.5.2. =============================*/
    // TODO

    /*============================= 1.5.3. =============================*/
    // TODO
};
