#include "functions.hpp"

#include <algorithm>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

void ParseCSV(const std::string& filename,
              std::map<int, std::string>& header_cols,
              std::map<std::string, std::vector<std::string>>& data_map) {}

int SumColumn(const std::string& column_name,
              std::map<std::string, std::vector<std::string>>& data_map) {
    return -1;
}

double FilterMostFrequentAvg(
    const std::string& key_col, std::string& value_col,
    std::map<std::string, std::vector<std::string>>& data_map) {
    return -1;
}

void SumTwoColumns(std::string& value_col1, std::string& value_col2,
                   const std::string& out_filename,
                   std::map<int, std::string>& header_cols,
                   std::map<std::string, std::vector<std::string>>& data_map) {}
